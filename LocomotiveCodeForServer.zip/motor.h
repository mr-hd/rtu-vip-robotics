void init_motor(int PIN_1, int PIN_2, int PWM_FREQ)
{
  ledcSetup(0, PWM_FREQ, 8);
  ledcAttachPin(PIN_1, 0);
  ledcSetup(1, PWM_FREQ, 8);
  ledcAttachPin(PIN_2, 1);
}

void motor_stop()
{
  ledcWrite(0, 0);
  ledcWrite(1, 0);
}

void set_motor_speed(int SPEED, int DIRECTION_INV)
{
  int actual_duty;
  motor_stop();
  if (SPEED < 0)
  {
    actual_duty = map(SPEED, 0, -100, 180, 255);
    ledcWrite(0 ^ DIRECTION_INV, actual_duty);
  }
  else if (SPEED > 0)
  {
    actual_duty = map(SPEED, 0, 100, 180, 255);
    ledcWrite(1 ^ DIRECTION_INV, actual_duty);
  }
}
