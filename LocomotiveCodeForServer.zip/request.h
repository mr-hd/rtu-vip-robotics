#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>

void init_wifi(const char* ssid, const char* password) {
  WiFi.begin(ssid, password);
  Serial.println("Connecting");
  int i = 0;
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    i++;
    if (i > 20) {
      ESP.restart();
    }
  }
  Serial.println("");
  Serial.print("Connected to WiFi network with IP Address: ");
  Serial.println(WiFi.localIP());
}

String send_request(String request) {
  String payload = "-1";
  int start = millis();
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(request.c_str());
    int httpResponseCode = http.GET();
    if (httpResponseCode > 0) {
      Serial.print("HTTP Response code: ");
      Serial.println(httpResponseCode);
      payload = http.getString();
      
      Serial.println(payload);
    }
    else {
      Serial.print("Error code: ");
      Serial.println(httpResponseCode);
    }
    // Free resources
    http.end();
  }
  int duration = millis() - start;
  Serial.println("Request duration = " + String(duration));
  return payload;
}
